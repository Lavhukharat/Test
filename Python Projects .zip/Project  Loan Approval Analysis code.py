import os
import pandas as pd
import numpy as np
from scipy.stats import mode
 
os.chdir("D:\\Learn software\\data science Greyatom\\greyatom notes\\Data Science Masters prog\\2 Python for Data Science\\4  Data Wrangling with Pandas\\project") 
os.getcwd()                
bank=pd.read_csv(r"Project  Loan Approval Analysis.csv")
type(bank)

categorical_var=bank.select_dtypes(include='object')
print("Categorical variables : ",categorical_var)

numerical_var=bank.select_dtypes(include='number')

banks= bank.drop(columns='Loan_ID')
# all the missing values filled.
banks.isnull().sum()
bank_mode = banks.mode().iloc[0]
banks.fillna(bank_mode, inplace=True)
banks.isnull().sum()

avg_loan_amount = banks.pivot_table(values=["LoanAmount"], index=["Gender","Married","Self_Employed"], aggfunc=np.mean)

loan_approved_se = banks.loc[(banks["Self_Employed"]=="Yes")  & (banks["Loan_Status"]=="Y"), ["Loan_Status"]].count()
loan_approved_se
loan_approved_nse = banks.loc[(banks["Self_Employed"]=="No")  & (banks["Loan_Status"]=="Y"), ["Loan_Status"]].count()
loan_approved_nse

percentage_se = (loan_approved_se * 100 / 614)
percentage_se=percentage_se[0]
percentage_nse = (loan_approved_nse * 100 / 614)
percentage_nse=percentage_nse[0]

loan_term = banks['Loan_Amount_Term'].apply(lambda x: int(x)/12 )
big_loan_term=len(loan_term[loan_term>=25])
columns_to_show = ['ApplicantIncome', 'Credit_History']
loan_groupby=banks.groupby(['Loan_Status'])
loan_groupby=loan_groupby[columns_to_show]
mean_values=loan_groupby.agg([np.mean])

#*******the end ****************#



