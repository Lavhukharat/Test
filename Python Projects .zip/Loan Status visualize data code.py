
import numpy as np 
import pandas as pd
import matplotlib.pyplot as plt
import os 
os.chdir("D:\\Learn software\\data science Greyatom\\greyatom notes\\Data Science Masters prog\\2 Python for Data Science\\5 Visualize Data using Matplotlib\\project")
os.getcwd()            
df=pd.read_csv(r"Loan Status.csv")
df.head()

loan_status=df['Loan_Status'].value_counts()
loan_status
plt.bar(loan_status.index, loan_status)

#Everyone needs money
property_and_loan=df.groupby(['Property_Area', 'Loan_Status']).size().unstack()
property_and_loan
property_and_loan.plot(kind='bar', stacked=False, figsize=(10,5))

plt.xlabel('Property_Area')
plt.ylabel('Loan_Status')
plt.title("Bar")
plt.xticks(rotation=45)

#Expensive Education
education_and_loan=df.groupby(['Education', 'Loan_Status']).size().unstack()
education_and_loan
education_and_loan.plot(kind='bar', stacked=True, figsize=(10,5))
plt.xlabel('Education Status')
plt.ylabel('Loan Status')
plt.xticks(rotation=45)

#Smarter and Richer?
graduate=df[df['Education']=='Graduate']
graduate
not_graduate=df[df['Education']=='Not Graduate']
not_graduate

graduate['LoanAmount'].plot(kind='density', label='Graduate')
not_graduate['LoanAmount'].plot(kind='density',label='Not Graduate')
plt.legend()

#Income vs Loan

fig, (ax_1, ax_2,ax_3) = plt.subplots(1,3, figsize=(12,6))

ax_1.scatter(df['ApplicantIncome'],df["LoanAmount"])
ax_1.set(title='Applicant Income')
ax_2.scatter(df['CoapplicantIncome'],df["LoanAmount"])
ax_2.set(title='Coapplicant Income')

df['TotalIncome']= df['ApplicantIncome']+ df['CoapplicantIncome']
ax_3.scatter(df['TotalIncome'],df["LoanAmount"])
ax_3.set(title='Total Income')

#***********the end************************#


