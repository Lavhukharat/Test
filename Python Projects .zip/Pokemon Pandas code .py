#************ Pandas Operations****************************#
import os
import numpy as np
import pandas as pd
os.getcwd() 
os.chdir("D:\\Learn software\\data science Greyatom\\greyatom notes\\Data Science Masters prog\\2 Python for Data Science\\4  Data Wrangling with Pandas")                
df=pd.read_csv(r"pokemon.csv")
df.describe()
df.head(5)
df.tail(5)
df.info()
df.dtypes
df.columns
df.shape
df.isnull().sum()
df.nunique()
df.dropna()

df['Name']
df[['Name','HP','Attack']]
df['Difference']=df['Attack']-df['Defense']

df.drop(['Difference'],inplace=True,axis=1)
df.iloc[0]
df.loc[0]
df.drop(index=0,axis=0,inplace=True)

df['Total'] = df['HP'] + df['Attack'] + df['Defense'] + df['Speed'] + df['Sp. Atk'] + df['Sp. Def']
print(df['Total'])

#Cleaning the Data
df_2 = df.set_index('#')
df_2.head()
df_2.reset_index(inplace = True)
df_2.head()

df.drop('#', inplace=True, axis=1) # Remove the '#' column permanently
df.head()
df.rename(columns={'HP':'Health Points', 'Sp. Atk': 'Attack speed points', 'Sp. Def': 'Defense speed points'}, inplace=True)
df.set_index('Name', inplace=True)
df.head()

type_1 = df['Type 1'].nunique()
print(df['Type 1'].unique())
df['Type 1'].value_counts()

type_two_num = df['Type 2'].nunique()
type_two = df['Type 2'].unique()
counts_type_two = df['Type 2'].value_counts()
no_type_two = df['Type 2'].isnull().sum()

#Exploring Numerical Columns*****
len_legendary = df['Legendary'].nunique()
print(len_legendary/len(df['Legendary']))
max_attack = df.Attack.idxmax()

healthiest_pokemon = df['Health Points'].idxmax()
healthiest_pokemon
special_attack_pokemon = df['Attack speed points'].idxmax()
special_attack_pokemon
special_defense_pokemon = df['Defense speed points'].idxmax()
special_defense_pokemon
fastest_pokemon = df['Speed'].idxmax()
fastest_pokemon

#3*****************************************************#

df = df[df.index.notnull()]
df
highest_legendary = df[df['Legendary'] == True]['Type 1'].value_counts().idxmax()
print(highest_legendary)   #Conditional Filtering
single_type_legendary = len(df[df['Type 2'].isnull() & df['Legendary'] == True])
print(single_type_legendary)

#**********Apply Functions****************************#
lower = np.min(df['Attack'])
upper = np.max(df['Attack'])
limit = upper - lower
mean = np.mean(df['Attack'])
def standardize(x,x_mean,x_range):
    return (x-x_mean)/x_range
print(df['Attack'].apply(lambda x:standardize(x,mean,limit)))

index = [i.upper() for i in df.index.values]
df.index = index

df['Type 1'] = df['Type 1'].apply(lambda x: x.lower())
df['Type 2'] = df['Type 2'].apply(lambda x: x.lower() if isinstance(x, str) else None)

#*********************Groupby and Sorting***************#
df.groupby('Generation')
df.groupby(['Generation','Type 1'])
df.groupby('Generation').groups
df.groupby('Generation')[['Attack speed points']].median()
df.groupby('Generation').agg({'Attack speed points':'median'})
df.groupby('Generation')[['Attack speed points']].median().sort_values(by='Attack speed points',ascending=False)
fastest_type = df.groupby('Type 1')['Speed'].agg(np.median).sort_values(ascending=False).idxmax()
print(fastest_type)

#********************Pivot Tables*******************#
pd.pivot_table(df,index='Generation',values='Attack',aggfunc='sum')
pd.pivot_table(df,index=['Legendary','Generation'],values='Attack')
pd.pivot_table(df,index='Legendary',values='Attack',columns='Generation')
df.pivot_table(index='Type 1', values='Attack speed points', columns='Generation')
pivot = df.pivot_table(index='Type 1', values='Attack speed points', columns='Generation')

#*********Merging DataFrame
df1 = pd.DataFrame({'fruit': ['apple', 'banana', 'orange'] * 3,
                    'weight': ['high', 'medium', 'low'] * 3,
                    'price': np.random.randint(0, 15, 9)})

df2 = pd.DataFrame({'product': ['apple', 'orange', 'pine'] * 2,
                    'kilo': ['high', 'low'] * 3,
                    'price': np.random.randint(0, 15, 6)})
merged = pd.merge(df1, df2, how='inner', left_on=['fruit', 'weight'], right_on=['product', 'kilo'], suffixes=['_left', '_right'])
print(merged)


#4***********************************************
Special_attack = df[["Attack speed points"]]
print(Special_attack.head())
def attack(num): 
  
    if num < 60: 
        return "Low Attack"
  
    elif num> 60 and num <= 120: 
        return "Normal Attack"
  
    else: 
        return "High Attack"

Special_attack['Attack speed points'] = Special_attack['Attack speed points'].apply(attack) 
print(Special_attack)

pokemon_type_avg = df.groupby('Type 1')['Total'].agg(np.mean).sort_values(ascending=False)
strongest_type = pokemon_type_avg.index[0]
print(strongest_type)
weakest_type = pokemon_type_avg.index[-1]
print(weakest_type)

df.index.name = 'Name'
pokemon_stats = df[df["Legendary"] == True][["Legendary","Generation","Attack"]]
print(pokemon_stats.head())
pokemon_stats_legendary = pokemon_stats.groupby(['Generation','Name'])[['Attack']].agg(np.mean).idxmax()[0]
print(pokemon_stats_legendary)

print("The end \b "*5)
####### The end #######



