
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
%matplotlib inline

os.chdir("D:\\Learn software\\data science Greyatom\\greyatom notes\\Data Science Masters prog\\2 Python for Data Science\\5 Visualize Data using Matplotlib\\1 Introduction Matplotlib") 
os.getcwd()                
df=pd.read_csv(r"pokemon.csv")
df.head()

df.set_index('Name', inplace=True)
df.head()
df.drop('#', inplace=True, axis=1)
df.head()

#******************************************
type_1_data = df['Type 1'].value_counts(ascending=False)
type_1_data
#plt.figure(figsize=[16,8])
plt.xlabel("Type 1 Pokemon Variants")
plt.ylabel("No of Pokemons")
plt.title("Distribution of pokemons across various Type 1 variants")
#plt.bar(type_1_data.index,type_1_data)
#OR
df['Type 1'].value_counts().plot(kind="bar")

#**********
type_2 = df['Type 2'].value_counts(ascending=False)
type_2.plot(kind='bar')

#*************
type_1 = pd.DataFrame(df.groupby(['Type 1'])['Attack'].mean())
type_1
type_2 = pd.DataFrame(df.groupby(['Type 2'])['Attack'].mean())
type_2

type_2.reset_index(inplace=True)
type_2
type_1.reset_index(inplace=True)
type_1

merged = pd.merge(type_1, type_2, left_on='Type 1', right_on='Type 2')
merged

merged.rename(columns={'Type 2': 'Type'}, inplace=True)
merged
plt.figure(figsize=(14,8))
plt.plot(merged['Type'], merged['Attack_x'], color='red')
plt.plot(merged['Type'], merged['Attack_y'], color='blue')
plt.xlabel('Types')
plt.ylabel('Mean Attack Points')
plt.title('Comparison of Mean Attack Points for variants of Type 1 and Type 2')
plt.legend(labels=['Type1', 'Type 2'])
plt.show()

#******************************************************************************************************************************************************************************************************

# Stacked Bar Chart
leg=df.groupby(['Type 1', 'Legendary']).size().unstack()
leg.plot(kind='bar', stacked=True, figsize=(10,5))
plt.xlabel('Type 1')
plt.ylabel('Frequency')
plt.xticks(rotation=45)
plt.title("Legendary analysis")
plt.show()

res = df.groupby(['Generation', 'Legendary']).size().unstack()	
res
res.plot(kind='bar', stacked=True, figsize=(10,5))
plt.show()

#*****Histogram**************
mean_attack = np.mean(df["Attack"])
mean_attack
dragon = df[df['Type 1'] == 'Dragon']
dragon
mean_dragon = np.mean(dragon['Attack'])
mean_dragon

dragon.hist(column='Attack', bins=8, figsize=(5,5))
plt.axvline(x=mean_attack, color='green')
plt.axvline(x=mean_dragon, color='black')
plt.show()

#Scatter Plot
plt.scatter(df['Attack'], df['Defense'])

# Scatter plot with pandas
df.plot.scatter(x='Attack', y='Defense')
electric = df[df['Type 1']=='Electric']
electric.plot.scatter(x='HP', y='Attack')
plt.show()

#Drawing Multiple Plots
fig, (ax_1,ax_2) = plt.subplots(1,2, figsize=(10,5))
# Stacked bar-chart representing counts
res = df.groupby(['Generation', 'Legendary']).size().unstack()
res.plot(kind='bar', stacked=True, ax=ax_1)
new_res = res.fillna(0)
new_res['Total'] = new_res[True] + new_res[False]
new_res[True] = (new_res[True] / new_res['Total']) * 100
new_res[False] = (new_res[False] / new_res['Total']) * 100
new_res.drop('Total', inplace=True, axis=1)
new_res.plot(kind='bar', stacked=True, ax=ax_2)

#**************the end*************************************************************#






